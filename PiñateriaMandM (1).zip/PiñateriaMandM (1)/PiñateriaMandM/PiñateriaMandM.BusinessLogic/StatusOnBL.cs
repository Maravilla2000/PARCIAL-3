﻿using PiñateriaMandM.DataAccess;
using PiñateriaMandM.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PiñateriaMandM.BusinessLogic
{
    public class StatusOnBL
    {
        private static StatusOnBL _instance;
        public static StatusOnBL Instance
        {
            get
            {
                return _instance ?? (_instance = new StatusOnBL());
            }
        }

        public bool Insert(StatusOn entity)
        {
            bool result = false;
            try
            {
                result = StatusOnDAL.Instance.Insert(entity);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            return result;
        }

        public bool Update(StatusOn entity)
        {
            bool result = false;
            try
            {
                result = StatusOnDAL.Instance.Update(entity);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            return result;
        }

        public bool Delete(int id)
        {
            bool result = false;
            try
            {
                result = StatusOnDAL.Instance.Delete(id);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            return result;
        }

        public List<StatusOn> SelectAll()
        {
            List<StatusOn> result = null;
            try
            {
                result = StatusOnDAL.Instance.SelectAll();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            return result;
        }

        public StatusOn SelectById(int id)
        {
            StatusOn result = null;
            try
            {
                result = StatusOnDAL.Instance.SelectById(id);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            return result;
        }
    }

}
