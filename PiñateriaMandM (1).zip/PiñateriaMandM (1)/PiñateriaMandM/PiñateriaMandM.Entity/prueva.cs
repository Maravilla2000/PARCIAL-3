﻿using System;
using System.Data.SqlClient;

class Program
{
    static void Main()
    {
        // Cadena de conexión
        string connectionString = "Data Source=LAPTOP-C72BQI9O\\SQLEXPRESS;Initial Catalog=PiñateriaMandM2;Integrated Security=True";

        // Intentar abrir la conexión
        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            try
            {
                connection.Open(); // Abre la conexión
                Console.WriteLine("Conexión exitosa a la base de datos.");
            }
            catch (SqlException ex)
            {
                Console.WriteLine("No se pudo conectar a la base de datos.");
                Console.WriteLine($"Error: {ex.Message}");
            }
            finally
            {
                connection.Close(); // Cierra la conexión (aunque el using lo hace automáticamente)
            }
        }
    }
}