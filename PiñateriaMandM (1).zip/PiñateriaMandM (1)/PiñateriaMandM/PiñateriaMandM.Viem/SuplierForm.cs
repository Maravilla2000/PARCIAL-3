﻿using PiñateriaMandM.BusinessLogic;
using PiñateriaMandM.Entity;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace PiñateriaMandM.Viem
{
    public partial class SuplierForm : Form
    {
        public SuplierForm()
        {
            InitializeComponent();
            LoadSuplier();
        }

        private void SuplierForm_Load(object sender, EventArgs e)
        {

        }

        private void BtnInsert_Click(object sender, EventArgs e)
        {
            
                // Collect data from the form inputs
                string name = TxtName.Text;
                string phone = TxtPhone.Text;
                string email = TxtEmail.Text;
                string contactperson = TxtContactPerson.Text;
                string adress = TxtAddress.Text;

                if (string.IsNullOrEmpty(name))
                {
                    MessageBox.Show("Please enter a category name.");
                    return;
                }

                // Create a new Category entity
                Supplier supplier = new Supplier
                {
                    Name = name,
                    Phone = phone,
                    Email = email,
                    Address = adress,
                    ContactPerson = contactperson
                };

                // Try to insert the category using CategoryBL
                bool result = SupplierBL.Instance.Insert(supplier);
                if (result)
                {
                    MessageBox.Show("Category inserted successfully!");
                    LoadSuplier(); // Refresh the DataGridView
                }
                else
                {
                    MessageBox.Show("Error inserting category.");
                }

                // Clear input fields after insertion
                TxtAddress.Clear();
                TxtName.Clear();
                TxtPhone.Clear();
                TxtEmail.Clear();
                TxtContactPerson.Clear();
                
            
            
        }

        private void LoadSuplier()
        {
            List<Supplier> supliers = SupplierBL.Instance.SelectAll();
            dataGridView1.DataSource = supliers;
        }

        private void BtnCancel_Click(object sender, EventArgs e)
        {
            Menu menu = new Menu();
            this.Hide();
            menu.Show();
        }
    }
}
