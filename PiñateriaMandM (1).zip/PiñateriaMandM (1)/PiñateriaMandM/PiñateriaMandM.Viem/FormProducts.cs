﻿using PiñateriaMandM.BusinessLogic;
using PiñateriaMandM.Entity;
using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace PiñateriaMandM.Viem
{
    public partial class FormProducts : Form
    {
        public FormProducts()
        {
            InitializeComponent();
            LoadCategories();
            PrductsLoad();
        }



        private void FrmInsertProduct_Load(object sender, EventArgs e)
        {
            // Cargar las categorías al cargar el formulario
           
        }

        private void LoadCategories()
        {
            List<Category> categories = CategoryBL.Instance.SelectAll();

            // Configurar el ComboBox para mostrar el nombre de la categoría y usar CategoryId como valor interno
            cmbCategory.DataSource = categories;
            cmbCategory.DisplayMember = "Name";  // Esto es lo que se mostrará (nombre de la categoría)
            cmbCategory.ValueMember = "CategoryId"; // Esto es lo que se usará internamente (ID de la categoría)
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void Products_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Recoger los datos de los controles
            string name = TxtName.Text;
            decimal price = 0;
            string description = TxtDescription.Text;
            int categoryId = (int)cmbCategory.SelectedValue;

            // Validar si el precio es un número decimal válido
            if (!decimal.TryParse(TxtPrice.Text, out price))
            {
                MessageBox.Show("Por favor, ingrese un precio válido.");
                return;
            }

            // Verificar que los campos no estén vacíos
            if (string.IsNullOrEmpty(name) || string.IsNullOrEmpty(description))
            {
                MessageBox.Show("Por favor, complete todos los campos.");
                return;
            }



            // Crear el objeto producto
            Products newProduct = new Products
            {
                Name = name,
                Price = price,
                Description = description,
                CategoriaId = categoryId
            };

            // Intentar insertar el producto usando ProductoBL
            bool result = ProductsBL.Instance.Insert(newProduct);
            if (result)
            {
                MessageBox.Show("Producto insertado correctamente.");
                ClearFields();
            }
            else
            {
                MessageBox.Show("Error al insertar el producto.");
            }

            PrductsLoad();
        }

        private void ClearFields()
        {
            TxtName.Clear();
            TxtPrice.Clear();
            TxtDescription.Clear();
            cmbCategory.SelectedIndex = -1; ;
        }


        private void PrductsLoad()
        {
            // Obtener los productos desde la capa de negocio (BL)
            List<Products> products = ProductsBL.Instance.SelectAll();

            // Asignar los productos al DataGridView
            dataGridView1.DataSource = products;
        }
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            Menu menu = new Menu();
            this.Hide();
            menu.Show();
        }
    }
}
