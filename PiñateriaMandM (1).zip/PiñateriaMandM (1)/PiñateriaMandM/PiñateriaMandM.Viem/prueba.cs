﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PiñateriaMandM.Viem
{
    public partial class prueba : Form
    {
        public prueba()
        {
            InitializeComponent();
        }

        private void prueba_Load(object sender, EventArgs e)
        {
            
        }

        private void btnCheckConnection_Click(object sender, EventArgs e)
        {
            // Cadena de conexión
            string connectionString = "Data Source=LAPTOP-C72BQI9O\\SQLEXPRESS;Initial Catalog=PiñateriaMandM2;Integrated Security=True";

            // Intentar abrir la conexión
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open(); // Abre la conexión
                    lblStatus.Text = "Conexión exitosa a la base de datos.";
                    lblStatus.ForeColor = System.Drawing.Color.Green;
                }
                catch (SqlException ex)
                {
                    lblStatus.Text = "No se pudo conectar a la base de datos.";
                    lblStatus.ForeColor = System.Drawing.Color.Red;
                    MessageBox.Show($"Error: {ex.Message}", "Error de Conexión", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                finally
                {
                    connection.Close(); // Cierra la conexión
                }
            }
        }
    }
    }

