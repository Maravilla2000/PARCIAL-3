﻿using PiñateriaMandM.BusinessLogic;
using PiñateriaMandM.Entity;
using System;
using System.Collections.Generic;
using System.Windows.Forms;
using System.Xml.Linq;

namespace PiñateriaMandM.Viem
{
    public partial class Insert : Form
    {
        public Insert()
        {
            InitializeComponent();
            LoadCategories();
        }

        private void Insert_Load(object sender, EventArgs e)
        {
            // Load existing categories into DataGridView when form loads
            LoadCategories();
        }

        // Method to load categories from the database into the DataGridView
        private void LoadCategories()
        {
            List<Category> categories = CategoryBL.Instance.SelectAll();
            dataGridViewCategories.DataSource = categories;
        }

        // Event handler for the Insert button
       

        private void button1_Click(object sender, EventArgs e)
        {
            // Collect data from the form inputs
            string name = txtName.Text;
            string description = txtDescription.Text;

            if (string.IsNullOrEmpty(name))
            {
                MessageBox.Show("Please enter a category name.");
                return;
            }

            // Create a new Category entity
            Category category = new Category
            {
                Name = name,
                Description = description
            };

            // Try to insert the category using CategoryBL
            bool result = CategoryBL.Instance.Insert(category);
            if (result)
            {
                MessageBox.Show("Category inserted successfully!");
                LoadCategories(); // Refresh the DataGridView
            }
            else
            {
                MessageBox.Show("Error inserting category.");
            }

            // Clear input fields after insertion
            txtName.Clear();
            txtDescription.Clear();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Menu menu = new Menu();
            this.Hide();
            menu.Show();
        }
    }
}
