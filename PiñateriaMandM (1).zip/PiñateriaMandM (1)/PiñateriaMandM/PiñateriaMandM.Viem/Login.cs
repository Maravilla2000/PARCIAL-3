﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PiñateriaMandM.Viem
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        private void BtnCancel_Click(object sender, EventArgs e)
        {
          Usertxt.Clear();
            Passwordtxt.Clear();   
        }

        private void BtnInitial_Click(object sender, EventArgs e)
        {
            if (Usertxt.Text == "GerardoTuPapi" && Passwordtxt.Text == "63031189")
            {
                Menu menu = new Menu();
                this.Hide();
                menu.Show();
            }

            else
            {
                MessageBox.Show("Credenciales Incorrectas","error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Usertxt.Clear();
                Passwordtxt.Clear();
            }
        }

        private void Login_Load(object sender, EventArgs e)
        {

        }
    }
}
