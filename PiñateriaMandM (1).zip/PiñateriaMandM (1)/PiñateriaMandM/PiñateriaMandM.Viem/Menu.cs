﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PiñateriaMandM.Viem
{
    public partial class Menu : Form
    {
        public Menu()
        {
            InitializeComponent();
        }

        private void Menu_Load(object sender, EventArgs e)
        {

        }

        private void btnCategory_Click(object sender, EventArgs e)
        {
            Insert inser = new Insert();
            this.Hide();
            inser.Show();

        }

        private void btnProduct_Click(object sender, EventArgs e)
        {
            FormProducts products = new FormProducts();
            this.Hide();
            products.Show();
        }

        private void btnEmployee_Click(object sender, EventArgs e)
        {
            EmployeeForm employee = new EmployeeForm();
            this.Hide();
            employee.Show();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            FormPurchaseDetail purchase = new FormPurchaseDetail();
            this.Hide();
            purchase.Show();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            PurchaseForm purchase = new PurchaseForm();
            this.Hide();
            purchase.Show();
        }

        private void btnViewDetail_Click(object sender, EventArgs e)
        {
            ViewDetail viewDetail = new ViewDetail();
            this.Hide();
            viewDetail.Show();

        }

        private void btnSuplier_Click(object sender, EventArgs e)
        {
            SuplierForm suplier = new SuplierForm();
            this.Hide();
            suplier.Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Login login = new Login();
            this.Hide();
            login.Show();
        }
    }
}
