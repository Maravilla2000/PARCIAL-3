﻿using PiñateriaMandM.BusinessLogic;
using PiñateriaMandM.Entity;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace PiñateriaMandM.Viem
{
    public partial class FormPosition : Form
    {
        public FormPosition()
        {
            InitializeComponent();
        }

        private void FormPosition_Load(object sender, EventArgs e)
        {

        }

        private void btnInsert_Click(object sender, EventArgs e)
        {
            string name = txtName.Text;
            decimal salary = 0;
            string description = txtDescription.Text;

            if (!decimal.TryParse(txtSalary.Text, out salary))
            {
                MessageBox.Show("Por favor, ingrese un precio válido.");
                return;
            }

            if (string.IsNullOrEmpty(name) || string.IsNullOrEmpty(description))
            {
                MessageBox.Show("Por favor, complete todos los campos.");
                return;
            }

            Position position = new Position
            {
                Name = name,
                Salary = salary,
                Description = description
            };

            bool result = PositionBL.Instance.Insert(position);
            if (result)
            {
                MessageBox.Show("Producto insertado correctamente.");
                ClearFields();
                LoadPosition();
            }
            else
            {
                MessageBox.Show("Error al insertar el producto.");
            }
        }

        private void LoadPosition()
        {
            // Obtener los productos desde la capa de negocio (BL)
            List<Position> position = PositionBL.Instance.SelectAll();

            // Asignar los productos al DataGridView
            dataGridView1.DataSource = position;
        }

        private void ClearFields()
        {
            txtName.Clear();
            txtSalary.Clear();
            txtDescription.Clear();
        }

        private void btn_Click(object sender, EventArgs e)
        {
            Menu menu = new Menu();
            this.Hide();
            menu.Show();
        }
    }
}
