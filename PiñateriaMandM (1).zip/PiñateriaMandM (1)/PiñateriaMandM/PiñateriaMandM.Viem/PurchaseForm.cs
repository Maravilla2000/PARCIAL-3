﻿using PiñateriaMandM.BusinessLogic;
using PiñateriaMandM.Entity;
using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace PiñateriaMandM.Viem
{
    public partial class PurchaseForm : Form
    {
        public PurchaseForm()
        {
            InitializeComponent();
            LoadSuppliers();
        }

        private void LoadSuppliers()
        {
            // Obtener la lista de proveedores desde la capa de negocio
            List<Supplier> suppliers = SupplierBL.Instance.SelectAll();

            // Configurar el ComboBox para mostrar el nombre del proveedor y usar SupplierId como valor interno
            cmbSupplier.DataSource = suppliers;
            cmbSupplier.DisplayMember = "Name";      // Lo que se mostrará en el ComboBox
            cmbSupplier.ValueMember = "SupplierId";  // ID usado internamente
            cmbSupplier.SelectedIndex = -1;          // Limpiar selección inicial
        }

        private void Purchase_Load(object sender, EventArgs e)
        {
            // Este método se activa al cargar el formulario. Agregar lógica aquí si es necesario.
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Recoger los datos de los controles
            DateTime purchaseDate;
            decimal totalAmount;
            int supplierId;

            // Validar si hay un proveedor seleccionado
            if (cmbSupplier.SelectedIndex == -1)
            {
                MessageBox.Show("Por favor, seleccione un proveedor.");
                return;
            }
            else
            {
                supplierId = (int)cmbSupplier.SelectedValue;
            }

            // Validar el total de la compra
            if (!decimal.TryParse(textBox3.Text, out totalAmount) )
            {
                MessageBox.Show("Por favor, ingrese un monto total válido.");
                return;
            }

            // Validar la fecha de la compra
            if (!DateTime.TryParse(textBox2.Text, out purchaseDate))
            {
                MessageBox.Show("Por favor, ingrese una fecha válida en el formato correcto.");
                return;
            }

            // Crear el objeto `Purchase` con los datos válidos
            Purchase purchase = new Purchase
            {
                PurchaseDate = purchaseDate,
                TotalAmount = totalAmount,
                SupplierId = supplierId
            };

            // Intentar insertar la compra en la base de datos
            bool result = PurchaseBL.Instance.Insert(purchase);
            if (result)
            {
                MessageBox.Show("Compra insertada correctamente.");
                ClearFields();

                // Abrir el formulario `FormPurchaseDetail` en caso de éxito
                FormPurchaseDetail formDetail = new FormPurchaseDetail();
                formDetail.Show();
                this.Hide();  // Opcional: ocultar este formulario actual
            }
            else
            {
                MessageBox.Show("Error al insertar la compra.");
            }
        }

        private void ClearFields()
        {
            // Limpiar campos después de la inserción
            textBox2.Clear();
            textBox3.Clear();
            cmbSupplier.SelectedIndex = -1;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Menu menu = new Menu();
            this.Hide();
            menu.Show();
        }
    }

}
