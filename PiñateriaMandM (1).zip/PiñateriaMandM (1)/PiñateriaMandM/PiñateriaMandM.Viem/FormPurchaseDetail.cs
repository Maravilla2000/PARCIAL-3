﻿using PiñateriaMandM.BusinessLogic;
using PiñateriaMandM.Entity;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace PiñateriaMandM.Viem
{
    public partial class FormPurchaseDetail : Form
    {
        public FormPurchaseDetail()
        {
            InitializeComponent();
            LoadPurchase();
            LoadProducts();

        }

        private void LoadProducts()
        {
            List<Products> producto = ProductsBL.Instance.SelectAll();

            cmbProducto.DataSource = producto;
            cmbProducto.DisplayMember = "Name";  // Esto es lo que se mostrará (nombre de la categoría)
            cmbProducto.ValueMember = "ProductId"; // Esto es lo que se usará internamente (ID de la categoría)
        }

        private void LoadPurchase()
        {
            List<Purchase> purchases = PurchaseBL.Instance.SelectAll();

            // Configurar el ComboBox para mostrar el nombre de la categoría y usar CategoryId como valor interno
            cmbPurchase.DataSource = purchases;
            cmbPurchase.DisplayMember = "PurchaseDate";  // Esto es lo que se mostrará (nombre de la categoría)
            cmbPurchase.ValueMember = "PurchaseId"; // Esto es lo que se usará internamente (ID de la categoría)
        }



        private void FormPurchaseDetail_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            decimal priceperunited = 0;
            int quantity = 0;
            int productoId = (int)cmbProducto.SelectedValue;
            int purchaseId = (int)cmbPurchase.SelectedValue;

            if (!decimal.TryParse(txtPrincePerUnit.Text, out priceperunited ))
            {
                MessageBox.Show("Por favor, ingrese un precio válido.");
                return;
            }

            if (!int.TryParse(txtQuantity.Text, out quantity))
            {
                MessageBox.Show("Por favor, ingrese una cantidad válido.");
                return;
            }

            PurchaseDetail detail = new PurchaseDetail
            {
               PurchaseId = purchaseId,
               Quantity = quantity,
               PricePerUnit = priceperunited,
               ProductsId = productoId,
            };

            bool result = PurchaseDetailBL.Instance.Insert(detail);
            if (result)
            {
                MessageBox.Show("detalle de Compra insertada correctamente.");
                ViewDetail formDetail = new ViewDetail();
                formDetail.Show();
                this.Hide();  // Opcional: ocultar este formulario actual

            }
            else
            {
                MessageBox.Show("Error al insertar el detalle de Compra.");
            }

            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            Menu menu = new Menu();
            this.Hide();
            menu.Show();
        }
    }
    }

