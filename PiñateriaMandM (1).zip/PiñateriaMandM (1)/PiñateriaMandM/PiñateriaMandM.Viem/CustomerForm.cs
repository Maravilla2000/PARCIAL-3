﻿using PiñateriaMandM.BusinessLogic;
using PiñateriaMandM.Entity;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PiñateriaMandM.Viem
{
    public partial class CustomerForm : Form
    {
        public CustomerForm()
        {
            InitializeComponent();
            CustomerFormLoad();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Obtener los datos del formulario
            string name = txtName.Text;
            string phone = txtPhone.Text;
            string address = txtAddress.Text;
            string delivery = TxtDelivery.Text;

            // Verificar que todos los campos estén llenos
            if (string.IsNullOrEmpty(name) || string.IsNullOrEmpty(phone) ||
                string.IsNullOrEmpty(address) || string.IsNullOrEmpty(delivery))
            {
                MessageBox.Show("Por favor, complete todos los campos.");
                return;
            }

            // Crear un nuevo objeto Customer
            Customer customer = new Customer
            {
                Name = name,
                Phone = phone,
                Address = address,
                DeliveryAddress = delivery
            };

            // Llamar a la capa de negocio para insertar el cliente
            bool result = CustomerBL.Instance.Insert(customer);
            if (result)
            {
                MessageBox.Show("Cliente insertado correctamente.");
                CustomerFormLoad(); // Recargar el DataGridView después de la inserción
                ClearFields(); // Limpiar los campos después de insertar
            }
            else
            {
                MessageBox.Show("Error al insertar el cliente.");
            }
        }

        // Método para cargar todos los clientes en el DataGridView
        private void CustomerFormLoad()
        {
            List<Customer> customers = CustomerBL.Instance.SelectAll();

            // Asignar los clientes al DataGridView
            dataGridView1.DataSource = customers;
        }

        // Método para limpiar los campos de entrada
        private void ClearFields()
        {
            txtName.Clear();
            txtPhone.Clear();
            txtAddress.Clear();
            TxtDelivery.Clear();
        }

        private void CustomerForm_Load(object sender, EventArgs e)
        {
            // Puede dejarse vacío si no necesita más configuración
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            Menu menu = new Menu();
            this.Hide();
            menu.Show();
        }
    }

}
