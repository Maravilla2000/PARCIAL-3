﻿using PiñateriaMandM.BusinessLogic;
using PiñateriaMandM.Entity;
using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace PiñateriaMandM.Viem
{
    public partial class EmployeeForm : Form
    {
        public EmployeeForm()
        {
            InitializeComponent();
            LoadEmploye();
        }

        private void LoadEmploye()
        {
            List<Position> positions = PositionBL.Instance.SelectAll();

            // Configurar el ComboBox para mostrar el nombre de la categoría y usar CategoryId como valor interno
            cmbPosition.DataSource = positions;
            cmbPosition.DisplayMember = "Name";  // Esto es lo que se mostrará (nombre de la categoría)
            cmbPosition.ValueMember = "PositionId"; // Esto es lo que se usará internamente (ID de la categoría)
        }

        private void Employee_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string firtsName = textBox1.Text;
            string lastname = textBox2.Text;
            string phone = textBox3.Text;
            string email = textBox4.Text;
            string address = textBox5.Text;
            int position = (int)cmbPosition.SelectedValue;

            if (string.IsNullOrEmpty(firtsName) || string.IsNullOrEmpty(lastname) ||
              string.IsNullOrEmpty(phone) || string.IsNullOrEmpty(email) ||
              string.IsNullOrEmpty(address))
            {
                MessageBox.Show("Por favor, complete todos los campos.");
                return;
            }

            Employee employee = new Employee
            {
                FirstName = firtsName,
                LastName = lastname,
                Phone = phone,
                Email = email,
                Address = address,
                PositionId = position
                
            };

            bool result = EmployeeBL.Instance.Insert(employee);
            if (result)
            {
                MessageBox.Show("Empleado insertado correctamente.");
                employeFormLoad(); // Recargar el DataGridView después de la inserción
                ClearFields(); // Limpiar los campos después de insertar
            }
            else
            {
                MessageBox.Show("Error al insertar el Empleado.");
            }
        }

        private void employeFormLoad()
        {
            List<Employee> employees = EmployeeBL.Instance.SelectAll();

            // Asignar los clientes al DataGridView
            dataGridView1.DataSource = employees;
        }

        private void ClearFields()
        {
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            textBox4.Clear();
            cmbPosition.SelectedIndex = -1;

        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            Menu menu = new Menu();
            this.Hide();
            menu.Show();
        }
    }
    }

