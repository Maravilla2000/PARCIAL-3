﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PiñateriaMandM.Entity;

namespace PiñateriaMandM.DataAccess
{
    public class PromotionDAL:Connection
    {
        private static PromotionDAL _instance;
        public static PromotionDAL Instance
        {
            get
            {
                if (_instance == null)
                    _instance = new PromotionDAL();
                return _instance;
            }
        }

        public bool Insert(Promotion entity)
        {
            bool result = false;

            using (SqlConnection conn = new SqlConnection(_cadena))
            {
                using (SqlCommand cmd = new SqlCommand("spInsertPromotion", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@Title", entity.Name);
                    cmd.Parameters.AddWithValue("@Description", entity.Description);
                    cmd.Parameters.AddWithValue("@Discount", entity.DiscountPercentage);
                    cmd.Parameters.AddWithValue("@StartDate", entity.StartDate);
                    cmd.Parameters.AddWithValue("@EndDate", entity.EndDate);

                    conn.Open();
                    result = cmd.ExecuteNonQuery() > 0;
                }
            }

            return result;
        }

        public bool Update(Promotion entity)
        {
            bool result = false;

            using (SqlConnection conn = new SqlConnection(_cadena))
            {
                using (SqlCommand cmd = new SqlCommand("spUpdatePromotion", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@PromotionId", entity.PromotionId);
                    cmd.Parameters.AddWithValue("@Title", entity.Name);
                    cmd.Parameters.AddWithValue("@Description", entity.Description);
                    cmd.Parameters.AddWithValue("@Discount", entity.DiscountPercentage);
                    cmd.Parameters.AddWithValue("@StartDate", entity.StartDate);
                    cmd.Parameters.AddWithValue("@EndDate", entity.EndDate);

                    conn.Open();
                    result = cmd.ExecuteNonQuery() > 0;
                }
            }

            return result;
        }

        public bool Delete(int id)
        {
            bool result = false;

            using (SqlConnection conn = new SqlConnection(_cadena))
            {
                using (SqlCommand cmd = new SqlCommand("spDeletePromotion", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@PromotionId", id);

                    conn.Open();
                    result = cmd.ExecuteNonQuery() > 0;
                }
            }

            return result;
        }

        public List<Promotion> SelectAll()
        {
            List<Promotion> result = null;

            using (SqlConnection conn = new SqlConnection(_cadena))
            {
                using (SqlCommand cmd = new SqlCommand("spPromotionSelectAll", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    conn.Open();
                    using (SqlDataReader dr = cmd.ExecuteReader(CommandBehavior.SingleResult))
                    {
                        if (dr != null)
                        {
                            result = new List<Promotion>();

                            while (dr.Read())
                            {
                                Promotion entity = new Promotion()
                                {
                                    PromotionId = dr.GetInt32(0),
                                    Name = dr.GetString(1),
                                    Description = dr.IsDBNull(2) ? null : dr.GetString(2),
                                    DiscountPercentage = dr.GetDecimal(3),
                                    StartDate = dr.GetDateTime(4),
                                    EndDate = dr.GetDateTime(5)
                                };

                                result.Add(entity);
                            }
                        }
                    }
                }
            }

            return result;
        }

        public Promotion SelectById(int id)
        {
            Promotion result = null;

            using (SqlConnection conn = new SqlConnection(_cadena))
            {
                using (SqlCommand cmd = new SqlCommand("spPromotionSelectById", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@PromotionId", id);

                    conn.Open();
                    using (SqlDataReader dr = cmd.ExecuteReader(CommandBehavior.SingleResult))
                    {
                        if (dr != null)
                        {
                            while (dr.Read())
                            {
                                result = new Promotion()
                                {
                                    PromotionId = dr.GetInt32(0),
                                    Name = dr.GetString(1),
                                    Description = dr.IsDBNull(2) ? null : dr.GetString(2),
                                    DiscountPercentage = dr.GetDecimal(3),
                                    StartDate = dr.GetDateTime(4),
                                    EndDate = dr.GetDateTime(5)
                                };
                            }
                        }
                    }
                }
            }

            return result;
        }
    }
}
