﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PiñateriaMandM.Entity;

namespace PiñateriaMandM.DataAccess
{
    public class ProductsDAL:Connection
    {
        private static ProductsDAL _instance;
        public static ProductsDAL Instance
        {
            get
            {
                if (_instance == null)
                    _instance = new ProductsDAL();
                return _instance;
            }
        }

        public bool Insert(Products entity)
        {
            bool result = false;

            using (SqlConnection conn = new SqlConnection(_cadena))
            {
                using (SqlCommand cmd = new SqlCommand("spProductInsert", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@Name", entity.Name);
                    cmd.Parameters.AddWithValue("@Price", entity.Price);
                    cmd.Parameters.AddWithValue("@Description", entity.Description);
                    cmd.Parameters.AddWithValue("@CategoriaId", entity.CategoriaId);

                    conn.Open();
                    result = cmd.ExecuteNonQuery() > 0;
                }
            }

            return result;
        }

        public bool Update(Products entity)
        {
            bool result = false;

            using (SqlConnection conn = new SqlConnection(_cadena))
            {
                using (SqlCommand cmd = new SqlCommand("spUpdateProduct", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@ProductId", entity.ProductId);
                    cmd.Parameters.AddWithValue("@Name", entity.Name);
                    cmd.Parameters.AddWithValue("@Price", entity.Price);
                    cmd.Parameters.AddWithValue("@Description", entity.Description);
                    cmd.Parameters.AddWithValue("@CategoriaId", entity.CategoriaId);

                    conn.Open();
                    result = cmd.ExecuteNonQuery() > 0;
                }
            }

            return result;
        }

        public bool Delete(int id)
        {
            bool result = false;

            using (SqlConnection conn = new SqlConnection(_cadena))
            {
                using (SqlCommand cmd = new SqlCommand("spDeleteProduct", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@ProductId", id);

                    conn.Open();
                    result = cmd.ExecuteNonQuery() > 0;
                }
            }

            return result;
        }

        public List<Products> SelectAll()
        {
            List<Products> result = null;

            using (SqlConnection conn = new SqlConnection(_cadena))
            {
                using (SqlCommand cmd = new SqlCommand("spProductsSelectAll", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    conn.Open();
                    using (SqlDataReader dr = cmd.ExecuteReader(CommandBehavior.SingleResult))
                    {
                        if (dr != null)
                        {
                            result = new List<Products>();

                            while (dr.Read())
                            {
                                Products _entity = new Products();

                                _entity.ProductId = dr.GetInt32(0);
                                    _entity.Name = dr.GetString(1);
                                    _entity.Price = dr.GetDecimal(2);
                                _entity.Description = dr.IsDBNull(3) ? null : dr.GetString(3);
                                _entity.CategoriaId = dr.GetInt32(4);

                                result.Add(_entity);
                            }
                        }
                    }
                }
            }

            return result;
        }

        public Products SelectById(int id)
        {
            Products result = null;

            using (SqlConnection conn = new SqlConnection(_cadena))
            {
                using (SqlCommand cmd = new SqlCommand("spProductSelectById", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@ProductId", id);

                    conn.Open();
                    using (SqlDataReader dr = cmd.ExecuteReader(CommandBehavior.SingleResult))
                    {
                        if (dr != null)
                        {
                            while (dr.Read())
                            {
                                result = new Products()
                                {
                                    ProductId = dr.GetInt32(0),
                                    Name = dr.GetString(1),
                                    Price = dr.GetDecimal(2),
                                    Description = dr.IsDBNull(3) ? null : dr.GetString(3),
                                    CategoriaId = dr.GetInt32(4)
                                };
                            }
                        }
                    }
                }
            }

            return result;
        }
    }
}