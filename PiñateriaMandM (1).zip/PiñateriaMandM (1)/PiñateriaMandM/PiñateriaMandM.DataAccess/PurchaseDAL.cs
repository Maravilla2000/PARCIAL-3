﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PiñateriaMandM.Entity;

namespace PiñateriaMandM.DataAccess
{
    public class PurchaseDAL:Connection
    {
        private static PurchaseDAL _instance;
        public static PurchaseDAL Instance
        {
            get
            {
                if (_instance == null)
                    _instance = new PurchaseDAL();
                return _instance;
            }
        }

        public bool Insert(Purchase entity)
        {
            bool result = false;

            using (SqlConnection conn = new SqlConnection(_cadena))
            {
                using (SqlCommand cmd = new SqlCommand("spPurchaseInsert", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@PurchaseDate", entity.PurchaseDate);
                    cmd.Parameters.AddWithValue("@TotalAmount", entity.TotalAmount);
                    cmd.Parameters.AddWithValue("@SupplierId", entity.SupplierId);

                    conn.Open();
                    result = cmd.ExecuteNonQuery() > 0;
                }
            }

            return result;
        }

        public bool Update(Purchase entity)
        {
            bool result = false;

            using (SqlConnection conn = new SqlConnection(_cadena))
            {
                using (SqlCommand cmd = new SqlCommand("spUpdatePurchase", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@PurchaseId", entity.PurchaseId);
                    cmd.Parameters.AddWithValue("@PurchaseDate", entity.PurchaseDate);
                    cmd.Parameters.AddWithValue("@TotalAmount", entity.TotalAmount);
                    cmd.Parameters.AddWithValue("@SupplierId", entity.SupplierId);

                    conn.Open();
                    result = cmd.ExecuteNonQuery() > 0;
                }
            }

            return result;
        }

        public bool Delete(int id)
        {
            bool result = false;

            using (SqlConnection conn = new SqlConnection(_cadena))
            {
                using (SqlCommand cmd = new SqlCommand("spDeletePurchase", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@PurchaseId", id);

                    conn.Open();
                    result = cmd.ExecuteNonQuery() > 0;
                }
            }

            return result;
        }

        public List<Purchase> SelectAll()
        {
            List<Purchase> result = null;

            using (SqlConnection conn = new SqlConnection(_cadena))
            {
                using (SqlCommand cmd = new SqlCommand("spPurchasesSelectAll", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    conn.Open();
                    using (SqlDataReader dr = cmd.ExecuteReader(CommandBehavior.SingleResult))
                    {
                        if (dr != null)
                        {
                            result = new List<Purchase>();

                            while (dr.Read())
                            {
                                Purchase entity = new Purchase()
                                {
                                    PurchaseId = dr.GetInt32(0),
                                    PurchaseDate = dr.GetDateTime(1),
                                    TotalAmount = dr.GetDecimal(2),
                                    SupplierId = dr.GetInt32(3)
                                };

                                result.Add(entity);
                            }
                        }
                    }
                }
            }

            return result;
        }

        public Purchase SelectById(int id)
        {
            Purchase result = null;

            using (SqlConnection conn = new SqlConnection(_cadena))
            {
                using (SqlCommand cmd = new SqlCommand("spPurchaseSelectById", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@PurchaseId", id);

                    conn.Open();
                    using (SqlDataReader dr = cmd.ExecuteReader(CommandBehavior.SingleResult))
                    {
                        if (dr != null)
                        {
                            while (dr.Read())
                            {
                                result = new Purchase()
                                {
                                    PurchaseId = dr.GetInt32(0),
                                    PurchaseDate = dr.GetDateTime(1),
                                    TotalAmount = dr.GetDecimal(2),
                                    SupplierId = dr.GetInt32(3)
                                };
                            }
                        }
                    }
                }
            }

            return result;
        }
    }
}
