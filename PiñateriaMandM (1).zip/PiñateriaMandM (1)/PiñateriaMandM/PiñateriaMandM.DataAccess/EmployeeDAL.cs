﻿using PiñateriaMandM.Entity;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PiñateriaMandM.DataAccess
{
    public class EmployeeDAL: Connection
    {
        private static EmployeeDAL _instance;
        public static EmployeeDAL Instance

        {

            get
            {
                if (_instance == null)
                    _instance = new EmployeeDAL();
                return _instance;


            }
        }

        public bool Insert(Employee entity)
        {
            bool result = false;

            using (SqlConnection conn = new SqlConnection(_cadena))
            {
                using (SqlCommand cmd = new SqlCommand("spEmployeeInsert", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@FirstName", entity.FirstName);
                    cmd.Parameters.AddWithValue("@LastName", entity.LastName);
                    cmd.Parameters.AddWithValue("@Phone", entity.Phone);
                    cmd.Parameters.AddWithValue("@Email", entity.Email);
                    cmd.Parameters.AddWithValue("@Address", entity.Address);
                    cmd.Parameters.AddWithValue("@PositionId", entity.PositionId);

                    conn.Open();
                    result = cmd.ExecuteNonQuery() > 0;
                }
            }

            return result;
        }

        public bool Update(Employee entity)
        {
            bool result = false;

            using (SqlConnection conn = new SqlConnection(_cadena))
            {
                using (SqlCommand cmd = new SqlCommand("spEmployeeUpdate", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@EmployeeId", entity.EmployeeId);
                    cmd.Parameters.AddWithValue("@FirstName", entity.FirstName);
                    cmd.Parameters.AddWithValue("@LastName", entity.LastName);
                    cmd.Parameters.AddWithValue("@Phone", entity.Phone);
                    cmd.Parameters.AddWithValue("@Email", entity.Email);
                    cmd.Parameters.AddWithValue("@Address", entity.Address);
                    cmd.Parameters.AddWithValue("@PositionId", entity.PositionId);

                    conn.Open();
                    result = cmd.ExecuteNonQuery() > 0;
                }
            }

            return result;
        }

        public bool Delete(int id)
        {
            bool result = false;

            using (SqlConnection conn = new SqlConnection(_cadena))
            {
                using (SqlCommand cmd = new SqlCommand("spEmployeeDelete", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@EmployeeId", id);

                    conn.Open();
                    result = cmd.ExecuteNonQuery() > 0;
                }
            }

            return result;
        }

        public Employee SelectById(int id)
        {
            Employee result = null;

            using (SqlConnection conn = new SqlConnection(_cadena))
            {
                using (SqlCommand cmd = new SqlCommand("spEmployeeSelectById", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@EmployeeId", id);

                    conn.Open();
                    using (SqlDataReader dr = cmd.ExecuteReader(CommandBehavior.SingleResult))
                    {
                        if (dr != null)
                        {
                            while (dr.Read())
                            {
                                result = new Employee()
                                {
                                    EmployeeId = dr.GetInt32(0),
                                    FirstName = dr.GetString(1),
                                    LastName = dr.GetString(2),
                                    Phone = dr.IsDBNull(3) ? null : dr.GetString(3),
                                    Email = dr.IsDBNull(4) ? null : dr.GetString(4),
                                    Address = dr.IsDBNull(5) ? null : dr.GetString(5),
                                    PositionId = dr.GetInt32(6)
                                };
                            }
                        }
                    }
                }
            }

            return result;
        }

        public List<Employee> SelectAll()
        {
            List<Employee> result = null;

            using (SqlConnection conn = new SqlConnection(_cadena))
            {
                using (SqlCommand cmd = new SqlCommand("spEmployeesSelectAll", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    conn.Open();
                    using (SqlDataReader dr = cmd.ExecuteReader(CommandBehavior.SingleResult))
                    {
                        if (dr != null)
                        {
                            result = new List<Employee>();

                            while (dr.Read())
                            {
                                Employee entity = new Employee()
                                {
                                    EmployeeId = dr.GetInt32(0),
                                    FirstName = dr.GetString(1),
                                    LastName = dr.GetString(2),
                                    Phone = dr.IsDBNull(3) ? null : dr.GetString(3),
                                    Email = dr.IsDBNull(4) ? null : dr.GetString(4),
                                    Address = dr.IsDBNull(5) ? null : dr.GetString(5),
                                    PositionId = dr.GetInt32(6)
                                };

                                result.Add(entity);
                            }
                        }
                    }
                }
            }

            return result;
        }






    }
}
